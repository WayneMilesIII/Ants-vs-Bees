//
// Created by 12539 on 11/3/2020.
//

#ifndef LAB5_BODYGUARD_H
#define LAB5_BODYGUARD_H


#include "Insect.h"

class Bodyguard : public Insect{
public:
    Bodyguard();
};


#endif //LAB5_BODYGUARD_H
