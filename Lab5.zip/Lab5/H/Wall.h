//
// Created by 12539 on 11/3/2020.
//

#ifndef LAB5_WALL_H
#define LAB5_WALL_H


#include "Insect.h"

class Wall: public Insect {
public:
    Wall();
};


#endif //LAB5_WALL_H
