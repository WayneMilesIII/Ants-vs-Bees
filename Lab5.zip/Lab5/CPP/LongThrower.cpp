//
// Created by 12539 on 11/3/2020.
//

#include "../H/LongThrower.h"

LongThrower::LongThrower() : Insect(){
    cost = 3;
    armor = 1;
    name = "Long Thrower";
    canMove = false;
    canAttack = true;
    attack = 1;
    type = "Ant";
}



