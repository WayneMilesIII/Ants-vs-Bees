//
// Created by 12539 on 11/2/2020.
//

#include "../H/Bee.h"


Bee::Bee() : Insect(){
     armor = 3;
     canMove = true;
     attack = 1;
     canAttack = true;
     name = "Bee";
     type = "Bee";
}


