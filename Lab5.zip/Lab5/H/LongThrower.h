//
// Created by 12539 on 11/3/2020.
//

#ifndef LAB5_LONGTHROWER_H
#define LAB5_LONGTHROWER_H


#include "Insect.h"

class LongThrower : public Insect {
public:
    LongThrower();
};


#endif //LAB5_LONGTHROWER_H
