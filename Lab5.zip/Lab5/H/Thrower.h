//
// Created by 12539 on 11/3/2020.
//

#ifndef LAB5_THROWER_H
#define LAB5_THROWER_H


#include "Insect.h"

class Thrower: public Insect {
public:
    Thrower();
};


#endif //LAB5_THROWER_H
