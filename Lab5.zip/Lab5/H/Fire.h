//
// Created by 12539 on 11/3/2020.
//

#ifndef LAB5_FIRE_H
#define LAB5_FIRE_H


#include "Insect.h"

class Fire: public Insect{
public:
    Fire();
};

#endif //LAB5_FIRE_H
