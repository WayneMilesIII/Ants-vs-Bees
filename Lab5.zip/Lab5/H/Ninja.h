//
// Created by 12539 on 11/3/2020.
//

#ifndef LAB5_NINJA_H
#define LAB5_NINJA_H


#include "Insect.h"

class Ninja : public Insect {
public:
   Ninja();
};


#endif //LAB5_NINJA_H
