#include <iostream>
#include "H/Game.h"

int main() {
    Game game;
    game.game_Loop();
    return 0;
}
