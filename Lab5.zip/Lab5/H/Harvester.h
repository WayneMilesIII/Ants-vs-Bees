//
// Created by 12539 on 11/2/2020.
//

#ifndef LAB5_HARVESTER_H
#define LAB5_HARVESTER_H
#include "Insect.h"

class Harvester: public Insect {
public:
    Harvester();
};


#endif //LAB5_HARVESTER_H
