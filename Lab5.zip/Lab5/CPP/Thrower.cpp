//
// Created by 12539 on 11/3/2020.
//

#include "../H/Thrower.h"

Thrower::Thrower() {
    cost = 4;
    armor = 1;
    canMove = false;
    name = "Thrower";
    canAttack = true;
    attack = 1;
    type = "Ant";
}