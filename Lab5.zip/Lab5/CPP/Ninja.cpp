//
// Created by 12539 on 11/3/2020.
//

#include "../H/Ninja.h"
Ninja::Ninja(): Insect(){
    cost = 6;
    armor = 1;
    name = "Ninja";
    canMove = false;
    canAttack = false;
    attack = 1;
    type = "Ant";
};

