//
// Created by 12539 on 11/3/2020.
//

#include "../H/QueenAnt.h"

QueenAnt::QueenAnt() : Insect(){
    beeAtQueen = false;
    attack = 0;
    canAttack = false;
    name = "Queen Ant";
    canMove = false;
    cost = 0;
    canBeCreated = false;
    armor = 1;
    type = "Ant";
};

