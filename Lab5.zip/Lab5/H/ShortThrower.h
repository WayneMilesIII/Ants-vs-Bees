//
// Created by 12539 on 11/3/2020.
//

#ifndef LAB5_SHORTTHROWER_H
#define LAB5_SHORTTHROWER_H


#include "Insect.h"

class ShortThrower : public Insect {
public:
    ShortThrower();
};


#endif //LAB5_SHORTTHROWER_H
