//
// Created by 12539 on 11/2/2020.
//

#ifndef LAB5_BEE_H
#define LAB5_BEE_H


#include "Insect.h"

class Bee : public Insect {
public:
   Bee();
};

#endif //LAB5_BEE_H
